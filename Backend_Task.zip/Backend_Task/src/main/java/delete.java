

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class delete
 */
@WebServlet("/delete")
public class delete extends HttpServlet {
	
	private Connection con;
	private PreparedStatement pstmt;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		HttpSession session=req.getSession();
		String email=req.getParameter("email");
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","Umashankar143@");
			
			String sql="delete from registration where Email=?";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, email);
			
			int x=pstmt.executeUpdate();
			if(x!=0)
			{
				session.setAttribute("delete", "successfully deleted");
				resp.sendRedirect("homePage.jsp");
			}
			else
			{
				session.setAttribute("delete", "student not found");
				resp.sendRedirect("homePage.jsp");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
