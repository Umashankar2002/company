

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class details
 */
@WebServlet("/details")
public class details extends HttpServlet {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet result;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String email=req.getParameter("email");
		HttpSession session=req.getSession();
		
		session.setAttribute("email", email);
		
		try
		{
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","Umashankar143@");
			
			String sql="select * from registration where Email=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, email);
			
			result=pstmt.executeQuery();
			
			ArrayList<String> arr=new ArrayList<>();
			if(result.next())
			{
				
				arr.add(result.getString(2));
				arr.add(result.getString(3));
				
				arr.add(result.getDate(5)+"");
				arr.add(result.getLong(6)+"");
				arr.add(result.getString(7));
				
				session.setAttribute("details",arr);
				resp.sendRedirect("update.jsp");
			}
			else
			{
				session.setAttribute("update", "person not found");
				resp.sendRedirect("homePage.jsp");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
