

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class registration
 */
@WebServlet("/registration")
public class registration extends HttpServlet {
	
	private Connection con;
	private PreparedStatement pstmt;
	
	

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		HttpSession session=req.getSession();
		
		String name=req.getParameter("name");
		String password=req.getParameter("password");
		double phone=Double.parseDouble(req.getParameter("phone"));
		String email=req.getParameter("email");
		LocalDate date=LocalDate.parse(req.getParameter("date"));
		
		System.out.println(date);
		String address=req.getParameter("address");
		
		
		
		
		try
		{
			String sql="insert into registration (Name,Password,Email,Date_Of_Birth,Phone_Number,address) values(?,?,?,?,?,?)";
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","Umashankar143@");
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1,name);
			
			pstmt.setString(2, password);
			pstmt.setString(3, email);
			pstmt.setDate(4, Date.valueOf(date));
			pstmt.setDouble(5,phone);
			pstmt.setString(6, address);
			
			
			int x=pstmt.executeUpdate();
			
			if(x!=0)
			{
				session.setAttribute("insert", "successfully inserted");
				resp.sendRedirect("homePage.jsp");
			}
			else
			{
				session.setAttribute("insert", "This Email is Already Created");
				resp.sendRedirect("homePage.jsp");
			}
			
		}
		catch(Exception e)
		{
			session.setAttribute("insert", "something wrong");
			resp.sendRedirect("homePage.jsp");
			
		}
	}
}
