

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class updateStudent
 */
@WebServlet("/update")
public class update extends HttpServlet {
	
	private Connection con;
	private PreparedStatement pstmt;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		HttpSession session=req.getSession();
		
		String name=req.getParameter("name");
		String password=req.getParameter("password");
		Long phone=Long.parseLong(req.getParameter("phone"));
		
		
		LocalDate date=LocalDate.parse(req.getParameter("date"));
		
		String address=req.getParameter("address");
		
		String email=(String)session.getAttribute("email");
		
		String sql="update registration set name=?,password=?,Date_Of_Birth=?,Phone_Number=?,Address=? where Email=?";
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","Umashankar143@");
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1,name);
			
			pstmt.setString(2, password);
			
			pstmt.setDate(3, Date.valueOf(date));
			pstmt.setLong(4,phone);
			pstmt.setString(5, address);
			
			pstmt.setString(6, email);
			
			int x=pstmt.executeUpdate();
			
			if(x!=0)
			{
				session.setAttribute("update", "successfully updated");
				resp.sendRedirect("homePage.jsp");
			}
			else
			{
				session.setAttribute("update", "something wrong");
				resp.sendRedirect("homePage.jsp");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
